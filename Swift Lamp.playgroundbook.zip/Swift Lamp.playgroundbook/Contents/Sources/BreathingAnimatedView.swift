//
//  BreathingAnimatedView.swift
//
// Created by Nathalia Inacio on 17/04/21.
//


import UIKit

public final class BreathingAnimatedView: UIView {
    
    public static let color: UIColor = UIColor(red: 170/255, green: 168/255, blue: 206/255, alpha: 1)
    public var numberOfNodes: Int = 8
    private lazy var layers = setUpLayers(withInstanceCount: numberOfNodes)
        
    private lazy var radius: CGFloat = {
        return min(bounds.width, bounds.height)/2
    }()
    
    
    private lazy var node: CALayer = {
        let circle = CALayer()
        circle.compositingFilter = "screenBlendMode"
        circle.frame = CGRect(origin: CGPoint(x: 0, y: -radius/2), size: CGSize(width: radius, height: radius))
        circle.backgroundColor = BreathingAnimatedView.color.withAlphaComponent(0.75).cgColor
        circle.cornerRadius = radius/2
        return circle
    }()
    
    private var nodeAngle: CATransform3D {
        let angle = -CGFloat.pi * 2.0 / CGFloat(numberOfNodes)
        return CATransform3DMakeRotation(angle, 0, 0, -1)
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setUpBackground()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUpBackground()
    }

    override public func layoutSubviews() {
        super.layoutSubviews()
        layers.position = center
    }
        
    private func setUpBackground() {
    backgroundColor = UIColor.clear
    layer.backgroundColor = UIColor.clear.cgColor
    layer.addSublayer(layers)
    }
    
    private func setUpLayers(withInstanceCount instanceCount: Int) -> CAReplicatorLayer {
        let layer = CAReplicatorLayer()
        layer.addSublayer(node)
        layer.instanceCount = instanceCount
        layer.instanceBlueOffset = (-0.33 / Float(numberOfNodes))
        layer.instanceTransform = nodeAngle
        return layer
    }
    
    public func startAnimations() {
        let center = CGPoint(x: layer.bounds.width/2 - radius, y: layer.bounds.height/2 - radius)
        node.add(CABasicAnimation.Custom.MoveAndReverse.animation(from: node.position, to: center),
                 forKey: CABasicAnimation.Custom.MoveAndReverse.key)
        
        node.add(CABasicAnimation.Custom.ScaleDownAndReverse.animation,
                 forKey: CABasicAnimation.Custom.ScaleDownAndReverse.key)
        
        layers.add(CABasicAnimation.Custom.RotateAndReverse.animation,
                            forKey: CABasicAnimation.Custom.RotateAndReverse.key)
    }
}
