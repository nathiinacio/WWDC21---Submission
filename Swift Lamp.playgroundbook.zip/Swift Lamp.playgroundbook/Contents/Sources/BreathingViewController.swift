//
//  BreathingViewController.swift
//
//
// Created by Nathalia Inacio on 17/04/21.
//

import UIKit
import PlaygroundSupport

public class BreathingViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    private var breathingTimer: Timer?
    private var containerView: UIView!
    private var breatheView: BreathingAnimatedView!
    private var isInhaling = false

    private var genieView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "Exhale")
        view.contentMode = .scaleAspectFill
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    public override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 62/255, green: 38/255, blue: 52/255, alpha: 1)
        containerView = UIView(frame: CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 429, height: 429))
        view.addSubview(containerView)
        view.addSubview(genieView)
        breatheView = BreathingAnimatedView(frame: containerView.frame)
        containerView.addSubview(breatheView)
        breatheView.translatesAutoresizingMaskIntoConstraints = true
        breatheView.center = CGPoint(x: containerView.bounds.midX, y: containerView.bounds.midY)
        breatheView.autoresizingMask = [.flexibleLeftMargin, .flexibleRightMargin, .flexibleTopMargin, .flexibleBottomMargin]
        
        breatheView.startAnimations()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(30), execute: {
            PlaygroundPage.current.assessmentStatus = .pass(message: "**Well done!** You rock breathing! The **minimum 30 seconds of breathing exercise** has already passed. How about **another** exercise to continue relaxing? Go to the [**Next Page**](@next)!")
        })
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        breathingTimer = Timer.scheduledTimer(timeInterval: 4, target: self, selector: #selector(animateGenie), userInfo: nil, repeats: true)
    }
        
    @objc private func animateGenie() {
        if isInhaling {
            self.genieView.image = UIImage(named: "Exhale")
        } else {
            self.genieView.image = UIImage(named: "Inhale")
        }
        
        isInhaling.toggle()
    }
    
    public override func viewDidLayoutSubviews() {
        containerView.translatesAutoresizingMaskIntoConstraints = false
        let horizontalConstraint = containerView.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        let verticalConstraint = containerView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -150)
        let widthConstraint = containerView.widthAnchor.constraint(equalToConstant: 429)
        let heightConstraint = containerView.heightAnchor.constraint(equalToConstant: 429)
        view.addConstraints([horizontalConstraint, verticalConstraint, widthConstraint, heightConstraint])
       
        if view.frame.width > view.frame.height {
            ///Landscape
            genieView.frame.size.width = (815.0/1024) * view.frame.width
            genieView.frame.size.height = (730.0 / 1024) * view.frame.width
            genieView.center.x = (500.0/1024) * view.frame.width
            genieView.center.y = (1250.0/1366) * view.frame.width
            
        } else {
            ///Portrait
            genieView.frame.size.width = (815.0/1366) * (view.frame.height)
            genieView.frame.size.height = (730.0/1366) * view.frame.height
            genieView.center.x = (500.0/1024) * view.frame.width
            genieView.center.y = (1250.0/1366) * view.frame.height
        }
        super.viewDidLayoutSubviews()
    }
}




