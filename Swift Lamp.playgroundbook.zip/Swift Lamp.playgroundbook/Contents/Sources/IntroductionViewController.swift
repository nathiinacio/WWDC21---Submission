//
//  IntroductionViewController.swift
//
//
//  Created by Nathalia Inacio on 17/04/21.
//

import UIKit
import PlaygroundSupport

public class IntroductionViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    private var rightSwipe: Int = 0
    private var leftSwipe: Int = 0
    
    private var currentStep: Int = 0
    
    private var genieMood: [String] = ["Surprised", "Sad", "Explaning", "Confused", "Thinking", "HalfPower"]
    private var genieLines: [String] = ["Holy macaroni, a human!\n Hello, it's a pleasure\n to meet you. I can't believe\n someone finally found my lamp!", "I'm sorry...\n You probably\n want your 3 wishes...\n But I'm not in my\n best shape...", "I've been stuck in\n that lamp for many years.\n Without being able to\n go outside or even\n see other people.\n I'm still a little stressed\n right now.", "Wait, what?\n You know how I feel?\n A pandemic? OMG!\n I'm so sorry to hear that...\nI imagine you are\n as stressed as I am.", "Why don't we do some\n relaxation exercises?\n I bet that in the end\n we will feel much better\n and I even will be powerful\n enough to fulfill\n your wishes.", "Super!\n You sound like\n a good friend!\n Now, come into\n my lamp."]

    private var backgroundView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "ZoomView")
        view.contentMode = .scaleAspectFill
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var assetView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "Lamp")
        view.contentMode = .scaleAspectFill
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isUserInteractionEnabled = true
        return view
    }()
    
    
    private var effectView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "GenieSmoke")
        view.contentMode = .scaleAspectFill
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()
    
    
    private var linesView: UILabel = {
        let label = UILabel(frame: .zero)
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .black
        label.textAlignment = .left
        label.numberOfLines = 10
        label.text = "Bravo, adventurer!! You've found the magical lamp!\n\n Might the tales be true?\n\n There's only one way to find out...\n\n Go ahead! Rub it to see what happens!"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    
    private var genieView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "Surprised")
        view.contentMode = .scaleAspectFit
        view.alpha = 0.0
        view.isHidden = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var speechBaloonView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "SpeechBallon")
        view.contentMode = .scaleAspectFill
        view.isHidden = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var genieLinesView: UILabel = {
        let label = UILabel(frame: .zero)
        label.font = UIFont.systemFont(ofSize: 15)
        label.textColor = .black
        label.textAlignment = .center
        label.numberOfLines = 10
        label.text = "Holy macaroni, a human!\n Hello, it's a pleasure to\n meet you. I can't believe\n someone finally\n found my lamp!"
        label.isHidden = true
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private var continueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.setImage(UIImage(named: "ContinueButton"), for: .normal)
        button.isHidden = true
        button.contentMode = .scaleAspectFill
        button.isUserInteractionEnabled = false
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    @objc private func updateView() {
        self.currentStep += 1
        self.genieView.image = UIImage(named: genieMood[currentStep])
        self.genieLinesView.text = genieLines[currentStep]
        if self.currentStep == 5 {
            self.continueButton.isHidden = true
            self.continueButton.isUserInteractionEnabled = false
            PlaygroundPage.current.assessmentStatus = .pass(message: "You met **Genie**! Ready to chill with your new friend? Go to the [**Next Page**](@next)!")
        }
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(backgroundView)
        view.addSubview(assetView)
        view.addSubview(linesView)
        view.addSubview(effectView)
        view.addSubview(speechBaloonView)
        view.addSubview(genieLinesView)
        view.addSubview(continueButton)
        view.addSubview(genieView)
        self.setUpContraints()
        let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(self.getSwipeAction(_:)))
        self.assetView.addGestureRecognizer(swipeGesture)
        
    }
    
    @objc private func getSwipeAction( _ recognizer : UISwipeGestureRecognizer){
        if recognizer.direction == .right{
            rightSwipe += 1
        } else if recognizer.direction == .left {
            leftSwipe += 1
        }
    
        if rightSwipe == 1 || leftSwipe == 1 {
            assetView.shake()
            effectView.isHidden = false
            pulsate()
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                self.assetView.isHidden = true
                self.effectView.isHidden = true
                self.linesView.isHidden = true
                self.backgroundView.image = UIImage(named: "DesertView")
                self.genieView.isHidden = false
                self.continueButton.addTarget(self, action:  #selector(self.updateView), for: .touchUpInside)
                self.animateGenie()
            })
        }
    }
    
    
    private func setUpContraints() {
        NSLayoutConstraint.activate([
            backgroundView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            backgroundView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            backgroundView.widthAnchor.constraint(equalTo: view.widthAnchor),
            backgroundView.heightAnchor.constraint(equalTo: view.heightAnchor),
        ])
    }
    
    public override func viewDidLayoutSubviews() {
        
        if view.frame.width > view.frame.height {
            ///Landscape
            assetView.frame.size.width = (554.0/1024) * view.frame.width
            assetView.frame.size.height = (305.0 / 1024) * view.frame.width
            assetView.center.x = (400.0/1024) * view.frame.width
            assetView.center.y = (800.0/1366) * view.frame.width
            
            linesView.frame.size.width = (800.0/1024) * view.frame.width
            linesView.frame.size.height = (300.0 / 1024) * view.frame.width
            linesView.center.x = (500.0/1024) * view.frame.width
            linesView.center.y = (1100.0/1366) * view.frame.width
            
            effectView.frame.size.width = (400.0/1024) * (view.frame.height)
            effectView.frame.size.height = (600.0/1024) * view.frame.height
            effectView.center.x = (700.0/1024) * view.frame.width
            effectView.center.y = (400.0/1366) * view.frame.height
            
            genieView.frame.size.width = (426.0/1024) * view.frame.width
            genieView.frame.size.height = (499.0 / 1024) * view.frame.width
            genieView.center.x = (700.0/1024) * view.frame.width
            genieView.center.y = (700.0/1366) * view.frame.width
            
            speechBaloonView.frame.size.width = (354.0/1024) * view.frame.width
            speechBaloonView.frame.size.height = (336.0 / 1024) * view.frame.width
            speechBaloonView.center.x = (400.0/1024) * view.frame.width
            speechBaloonView.center.y = (400.0/1366) * view.frame.width
            
            genieLinesView.frame.size.width = (354.0/1024) * view.frame.width
            genieLinesView.frame.size.height = (300.0 / 1024) * view.frame.width
            genieLinesView.center.x = (400.0/1024) * view.frame.width
            genieLinesView.center.y = (400.0/1366) * view.frame.width
            
            continueButton.frame.size.width = (414.0/1024) * view.frame.width
            continueButton.frame.size.height = (87.0 / 1024) * view.frame.width
            continueButton.center.x = (500.0/1024) * view.frame.width
            continueButton.center.y = (1100.0/1366) * view.frame.width
                    
        } else {
            ///Portrait
            assetView.frame.size.width = (554.0/1366) * (view.frame.height)
            assetView.frame.size.height = (305.0/1366) * view.frame.height
            assetView.center.x = (400.0/1024) * view.frame.width
            assetView.center.y = (800.0/1366) * view.frame.height
            
            linesView.frame.size.width = (800.0/1366) * (view.frame.height)
            linesView.frame.size.height = (300.0/1366) * view.frame.height
            linesView.center.x = (500.0/1024) * view.frame.width
            linesView.center.y = (1100.0/1366) * view.frame.height
            
            effectView.frame.size.width = (400.0/1366) * (view.frame.height)
            effectView.frame.size.height = (600.0/1366) * view.frame.height
            effectView.center.x = (700.0/1024) * view.frame.width
            effectView.center.y = (400.0/1366) * view.frame.height
            
            genieView.frame.size.width = (426.0/1366) * (view.frame.height)
            genieView.frame.size.height = (499.0/1366) * view.frame.height
            genieView.center.x = (700.0/1024) * view.frame.width
            genieView.center.y = (700.0/1366) * view.frame.height
        
            speechBaloonView.frame.size.width = (354.0/1366) * (view.frame.height)
            speechBaloonView.frame.size.height = (336.0/1366) * view.frame.height
            speechBaloonView.center.x = (400.0/1024) * view.frame.width
            speechBaloonView.center.y = (400.0/1366) * view.frame.height
        
            genieLinesView.frame.size.width = (354.0/1366) * (view.frame.height)
            genieLinesView.frame.size.height = (300.0/1366) * view.frame.height
            genieLinesView.center.x = (400.0/1024) * view.frame.width
            genieLinesView.center.y = (400.0/1366) * view.frame.height
            
            continueButton.frame.size.width = (414.0/1366) * (view.frame.height)
            continueButton.frame.size.height = (87.0/1366) * view.frame.height
            continueButton.center.x = (500.0/1024) * view.frame.width
            continueButton.center.y = (1100.0/1366) * view.frame.height
        }
        
        super.viewDidLayoutSubviews()
    }
    
    private func animateGenie() {
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.genieView.fadeIn()
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
            self.speechBaloonView.isHidden = false
            self.genieLinesView.isHidden = false
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(3), execute: {
            self.continueButton.isHidden = false
            self.continueButton.isUserInteractionEnabled = true
            self.pulsateButton()
        })
    }
    
    private func pulsate() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.3
        pulse.fromValue = 0.98
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 1000
        pulse.initialVelocity = 0.3
        pulse.damping = 1.0
        effectView.layer.add(pulse, forKey: "pulseAnimation")
    }
    
    private func pulsateButton() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.3
        pulse.fromValue = 0.98
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 1000
        pulse.initialVelocity = 0.3
        pulse.damping = 1.0
        continueButton.layer.add(pulse, forKey: "pulseAnimation")
    }
}

extension UIImageView {
    func shake(duration timeDuration: Double = 0.3, repeat countRepeat: Float = 10000){
            let animation = CABasicAnimation(keyPath: "position")
            animation.duration = timeDuration
            animation.repeatCount = countRepeat
            animation.autoreverses = true
            animation.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 10, y: self.center.y))
            animation.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 10, y: self.center.y))
            self.layer.add(animation, forKey: "position")
        }
    
    func fadeTo(_ alpha: CGFloat, duration: TimeInterval = 0.3) {
      DispatchQueue.main.async {
        UIView.animate(withDuration: duration) {
          self.alpha = alpha
        }
      }
    }

    func fadeIn(_ duration: TimeInterval = 0.7) {
      fadeTo(1.0, duration: duration)
    }
}
