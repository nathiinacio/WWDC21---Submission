//
//  BreathingDefaultViewController.swift
//
//
//  Created by Nathalia Inacio on 17/04/21.
//

import UIKit
import PlaygroundSupport

public class BreathingDefaultViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    private var newView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "BreathingDefault")
        view.contentMode = .scaleAspectFill
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(newView)
        self.setUpContraints()
    }
    
    private func setUpContraints() {
        NSLayoutConstraint.activate([
            newView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            newView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            newView.widthAnchor.constraint(equalTo: view.widthAnchor),
            newView.heightAnchor.constraint(equalTo: view.heightAnchor)
            ])
    }
}
