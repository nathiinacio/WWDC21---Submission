//
//  Ground.swift
//
//
//  Created by Nathalia Inacio on 15/04/21.
//

import Foundation

public enum Ground: String {
    case Animals = "Animals"
    case Flowers = "Flowers"
    case House = "House"
}
