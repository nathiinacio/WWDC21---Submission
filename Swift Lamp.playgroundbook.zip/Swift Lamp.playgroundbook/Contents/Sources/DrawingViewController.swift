//
//  DrawingViewController.swift
//
//  Created by Nathalia Mariz de Almeida Salgado Inacio on 18/04/21.
//

import UIKit
import PlaygroundSupport

public class DrawingViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    private var isChoosingColor: Bool = false
    private var currentColor: UIColor = .black
    
    private var drawingView: DrawingView = {
        let view = DrawingView(frame: .zero)
        view.backgroundColor = .white
        view.contentMode = .scaleAspectFill
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var chooseColorView: UIView = {
        let view = UIView(frame: .zero)
        view.contentMode = .scaleAspectFill
        view.backgroundColor = UIColor(ciColor: .black).withAlphaComponent(0.25)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()
    
    private var changeColorButton: UIButton = {
        let view = UIButton(frame: .zero)
        view.contentMode = .scaleAspectFill
        view.setImage(UIImage(named: "ColorIcon"), for: .normal)
        view.isUserInteractionEnabled = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var eraseButton: UIButton = {
        let view = UIButton(frame: .zero)
        view.contentMode = .scaleAspectFill
        view.setImage(UIImage(named: "EraseIcon"), for: .normal)
        view.isUserInteractionEnabled = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    
    private var drawButton: UIButton = {
        let view = UIButton(frame: .zero)
        view.contentMode = .scaleAspectFill
        view.setImage(UIImage(named: "DrawIcon"), for: .normal)
        view.isUserInteractionEnabled = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var pinkColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = UIColor(red: 244/255, green: 144/255, blue: 151/255, alpha: 1)
        button.isUserInteractionEnabled = true
        button.tag = 7
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private var purpleColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = UIColor(red: 114/255, green: 9/255, blue: 183/255, alpha: 1)
        button.isUserInteractionEnabled = true
        button.tag = 6
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private var darkBlueColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = UIColor(red: 29/255, green: 53/255, blue: 87/255, alpha: 1)
        button.isUserInteractionEnabled = true
        button.translatesAutoresizingMaskIntoConstraints = false
        button.tag = 4
        return button
    }()
    
    private var lightBlueColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = UIColor(red: 95/255, green: 168/255, blue: 211/255, alpha: 1)
        button.tag = 5
        button.isUserInteractionEnabled = true
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private var yellowColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = UIColor(red: 255/255, green: 230/255, blue: 109/255, alpha: 1)
        button.isUserInteractionEnabled = true
        button.tag = 1
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private var redColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = UIColor(red: 255/255, green: 58/255, blue: 32/255, alpha: 1)
        button.tag = 0
        button.isUserInteractionEnabled = true
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private var greenColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = UIColor(red: 82/255, green: 183/255, blue: 136/255, alpha: 1)
        button.isUserInteractionEnabled = true
        button.tag = 3
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private var orangeColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = UIColor(red: 241/255, green: 115/255, blue: 0/255, alpha: 1)
        button.isUserInteractionEnabled = true
        button.tag = 2
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    
    private var blackColorButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.contentMode = .scaleAspectFill
        button.backgroundColor = .black
        button.tag = 8
        button.isUserInteractionEnabled = true
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    
    private var colorsStackView: UIStackView = {
        let stack = UIStackView(frame: .zero)
        stack.axis = .horizontal
        stack.distribution = .equalSpacing
        stack.alignment = .center
        stack.backgroundColor = .red
        stack.spacing = 5.0
        return stack
    }()
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        drawingCanvasSetUp()
        
        view.addSubview(drawingView)
        drawingView.addSubview(chooseColorView)
        drawingView.addSubview(changeColorButton)
        drawingView.addSubview(drawButton)
        drawingView.addSubview(eraseButton)

        chooseColorView.addSubview(pinkColorButton)
        chooseColorView.addSubview(purpleColorButton)
        chooseColorView.addSubview(darkBlueColorButton)
        chooseColorView.addSubview(lightBlueColorButton)
        chooseColorView.addSubview(yellowColorButton)
        chooseColorView.addSubview(greenColorButton)
        chooseColorView.addSubview(redColorButton)
        chooseColorView.addSubview(orangeColorButton)
        chooseColorView.addSubview(blackColorButton)
        
        self.changeColorButton.addTarget(self, action:  #selector(self.showColors), for: .touchUpInside)
        self.eraseButton.addTarget(self, action:  #selector(self.erase), for: .touchUpInside)
        self.drawButton.addTarget(self, action:  #selector(self.draw), for: .touchUpInside)
    
        self.pinkColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
        self.purpleColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
        self.darkBlueColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
        self.lightBlueColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
        self.yellowColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
        self.greenColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
        self.redColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
        self.orangeColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
        self.blackColorButton.addTarget(self, action:  #selector(self.changeColor), for: .touchUpInside)
                
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(15), execute: {
            PlaygroundPage.current.assessmentStatus = .pass(message: "Hey! Still drawing? Don't need to rush! Take your time to relax! Just don't forget to go to our [**Next Page**](@next) to say goodbye to Genie. **You still have your 3 wishes, remember?**")
        })
    }
    
    private func drawingCanvasSetUp() {
        drawingView.enableDrawing()
    }
    
    private func animatebutton(button: UIButton, scale: Bool) {
        if scale {
            UIView.animate(withDuration: 0.5) {
                button.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
            }
        } else {
            UIView.animate(withDuration: 0.5) {
                button.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            }
        }
    }
    
    @objc private func showColors() {
        
        self.drawingView.bringSubviewToFront(self.chooseColorView)
        self.drawingView.bringSubviewToFront(self.changeColorButton)
        self.drawingView.bringSubviewToFront(self.eraseButton)
        self.drawingView.bringSubviewToFront(self.drawButton)
        
        if chooseColorView.isHidden {
            animatebutton(button: changeColorButton, scale: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(Int(0.7)), execute: {
                self.isChoosingColor.toggle()
                self.chooseColorView.isHidden.toggle()
                self.drawingView.bringSubviewToFront(self.chooseColorView)
            })
        } else {
            self.isChoosingColor.toggle()
            self.chooseColorView.isHidden.toggle()
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(Int(0.7)), execute: {
                self.animatebutton(button: self.changeColorButton, scale: false)
            })
        }
    }
    
    @objc private func erase() {
        animatebutton(button: drawButton, scale: false)
        animatebutton(button: eraseButton, scale: true)
        drawingView.enableErasing()
        self.drawingView.bringSubviewToFront(self.chooseColorView)
        self.drawingView.bringSubviewToFront(self.changeColorButton)
        self.drawingView.bringSubviewToFront(self.eraseButton)
        self.drawingView.bringSubviewToFront(self.drawButton)
    }
    
    @objc private func draw() {
        animatebutton(button: eraseButton, scale: false)
        animatebutton(button: drawButton, scale: true)
        drawingView.enableDrawing()
        self.drawingView.bringSubviewToFront(self.chooseColorView)
        self.drawingView.bringSubviewToFront(self.changeColorButton)
        self.drawingView.bringSubviewToFront(self.eraseButton)
        self.drawingView.bringSubviewToFront(self.drawButton)
    }
    
    @objc private func changeColor(_ sender: Any) {
        let pickedColor: UIColor = colorsArray[(sender as! UIButton).tag]
        drawingView.changingLineColor(newColor: pickedColor)
        isChoosingColor = false
        chooseColorView.isHidden = true
    }
    
    public override func viewDidLayoutSubviews() {
        self.buttonsConstraints()
        
        NSLayoutConstraint(item: drawingView, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
           NSLayoutConstraint(item: drawingView, attribute: NSLayoutConstraint.Attribute.centerY, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1, constant: 0).isActive = true
           NSLayoutConstraint(item: drawingView, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.width, multiplier: 1, constant: 0).isActive = true
           NSLayoutConstraint(item: drawingView, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.height, multiplier: 1, constant: 0).isActive = true
        
        NSLayoutConstraint(item: changeColorButton, attribute: NSLayoutConstraint.Attribute.leading, relatedBy: NSLayoutConstraint.Relation.equal, toItem: drawingView, attribute: NSLayoutConstraint.Attribute.leading, multiplier: 1, constant: 40).isActive = true
           NSLayoutConstraint(item: changeColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: drawingView, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: 70).isActive = true
           NSLayoutConstraint(item: changeColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50).isActive = true
           NSLayoutConstraint(item: changeColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50).isActive = true
        
        NSLayoutConstraint(item: eraseButton, attribute: NSLayoutConstraint.Attribute.trailing, relatedBy: NSLayoutConstraint.Relation.equal, toItem: drawingView, attribute: NSLayoutConstraint.Attribute.trailing, multiplier: 1, constant: -40).isActive = true
           NSLayoutConstraint(item: eraseButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: drawingView, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: 70).isActive = true
           NSLayoutConstraint(item: eraseButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50).isActive = true
           NSLayoutConstraint(item: eraseButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50).isActive = true
        
        NSLayoutConstraint(item: drawButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: eraseButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
           NSLayoutConstraint(item: drawButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: eraseButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
           NSLayoutConstraint(item: drawButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50).isActive = true
           NSLayoutConstraint(item: drawButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50).isActive = true
        
        NSLayoutConstraint(item: chooseColorView, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: changeColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
           NSLayoutConstraint(item: chooseColorView, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: changeColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 25).isActive = true
           NSLayoutConstraint(item: chooseColorView, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 65).isActive = true
           NSLayoutConstraint(item: chooseColorView, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 410).isActive = true
        
        super.viewDidLayoutSubviews()
    }
    
    
    private func buttonsConstraints() {
        NSLayoutConstraint(item: pinkColorButton, attribute: NSLayoutConstraint.Attribute.leading, relatedBy: NSLayoutConstraint.Relation.equal, toItem: chooseColorView, attribute: NSLayoutConstraint.Attribute.leading, multiplier: 1, constant: 20).isActive = true
           NSLayoutConstraint(item: pinkColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: chooseColorView, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: 10).isActive = true
        NSLayoutConstraint(item: pinkColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: pinkColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        
        NSLayoutConstraint(item: purpleColorButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: pinkColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
        NSLayoutConstraint(item: purpleColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: pinkColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
        NSLayoutConstraint(item: purpleColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: purpleColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        
        
        NSLayoutConstraint(item: yellowColorButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: purpleColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
        NSLayoutConstraint(item: yellowColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: purpleColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
        NSLayoutConstraint(item: yellowColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: yellowColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        
        
        NSLayoutConstraint(item: blackColorButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: yellowColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
        NSLayoutConstraint(item: blackColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: yellowColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
        NSLayoutConstraint(item: blackColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: blackColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        
        
        NSLayoutConstraint(item: orangeColorButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: blackColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
        NSLayoutConstraint(item: orangeColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: blackColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
        NSLayoutConstraint(item: orangeColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: orangeColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        
        NSLayoutConstraint(item: lightBlueColorButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: orangeColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
        NSLayoutConstraint(item: lightBlueColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: orangeColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
        NSLayoutConstraint(item: lightBlueColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: lightBlueColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        
        
        NSLayoutConstraint(item: darkBlueColorButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: lightBlueColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
        NSLayoutConstraint(item: darkBlueColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: lightBlueColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
        NSLayoutConstraint(item: darkBlueColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: darkBlueColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        
        NSLayoutConstraint(item: greenColorButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: darkBlueColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
        NSLayoutConstraint(item: greenColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: darkBlueColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
        NSLayoutConstraint(item: greenColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: greenColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        
        NSLayoutConstraint(item: redColorButton, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: greenColorButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0).isActive = true
        NSLayoutConstraint(item: redColorButton, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: greenColorButton, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 20).isActive = true
        NSLayoutConstraint(item: redColorButton, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
        NSLayoutConstraint(item: redColorButton, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 25).isActive = true
    }
}

