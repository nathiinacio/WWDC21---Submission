//
//  DrawingView.swift
//
//  Created by Nathalia Mariz de Almeida Salgado Inacio on 18/04/21.
//


import UIKit

class DrawingView: UIView {
    
    var color: UIColor!
    var width: CGFloat! = 3.0
    var alphaNumber: Float! = 1.0
    var path: UIBezierPath!
    var touchPoint: CGPoint!
    var startingPoint: CGPoint!
    
    override func layoutSubviews() {
        self.clipsToBounds = true
        self.isMultipleTouchEnabled = false
    }
    
    func enableDrawing() {
        color = .black
        width = 3.0
    }
    
    func enableErasing() {
        color = UIColor.white
        width = 40
    }
    
    func changingLineColor(newColor: UIColor) {
        color = newColor
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        startingPoint = touch?.location(in: self)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        touchPoint = touch?.location(in: self)
        path = UIBezierPath()
        path.move(to: startingPoint)
        path.addLine(to: touchPoint)
        startingPoint = touchPoint
        drawLayers()
    }
    
    func getLastTouchPoint() -> CGPoint {
        if touchPoint == nil {
            return CGPoint(x: 0.0, y: 0.0)
        } else {
            return touchPoint
        }
    }
    
    func drawLayers() {
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = color.cgColor
        shapeLayer.lineWidth = width
        shapeLayer.opacity = alphaNumber
        shapeLayer.fillColor = UIColor.clear.cgColor
        self.layer.addSublayer(shapeLayer)
        self.setNeedsDisplay()
    }
    
}
