//
//  HappyPlaceViewController.swift
// 
//
//  Created by Nathalia Mariz de Almeida Salgado Inacio on 18/04/21.
//

import UIKit
import AVFoundation
import PlaygroundSupport

public class HappyPlaceViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    public var thisBackground: Locations?
    public var thisInSky: Sky?
    public var thisInGround: Ground?
    
    private var backgroundName: String?
    private var skyName: String?
    private var groundName: String?
    
    private var player: AVAudioPlayer?
    private var soundName: String?

    private var backgroundView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.contentMode = .scaleAspectFill
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var skyView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.contentMode = .scaleAspectFit
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private func setUpChoices() {
        switch thisBackground {
        case .Hills:
            self.backgroundName = "Hills"
            self.soundName = "Warm Evening Outdoors"
        case .Lake:
            self.backgroundName = "Lake"
            self.soundName = "Water Running By"
        case .MountainView:
            self.backgroundName = "Mountain"
            self.soundName = "Leaves Russle On Tree"
        case .none:
            self.backgroundName = "Lake"
            self.soundName = "Water Running By"
        }
        
        switch thisInSky {
        case .Birds:
            self.skyName = "Birds"
        case .Rainbow:
            self.skyName = "Rainbow"
        case .Sun:
            self.skyName = "Sun"
        case .none:
            self.skyName = "Birds"
        }
        
        switch thisInGround {
        case .House:
            self.groundName = "House"
        case .Animals:
            self.groundName = "Animals"
        case .Flowers:
            self.groundName = "Flowers"
        case .none:
            self.groundName = "House"
        }
    }
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        setUpChoices()
        view.addSubview(backgroundView)
        view.addSubview(skyView)
        self.setUpContraints()
        self.backgroundView.image = UIImage(named: "\(backgroundName ?? "Lake")+\(groundName ?? "House")")
        self.skyView.image = UIImage(named: skyName ?? "Birds")
        self.playSound()
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(3), execute: {
            PlaygroundPage.current.assessmentStatus = .pass(message: "This is what I call a **happy place**! What a breath taking view you set up! Feeling better? Let's go to the last exercise! Go to the [**Next Page**](@next)!")
        })
    }
    
    private func setUpContraints() {
        NSLayoutConstraint.activate([
            backgroundView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            backgroundView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            backgroundView.widthAnchor.constraint(equalTo: view.widthAnchor),
            backgroundView.heightAnchor.constraint(equalTo: view.heightAnchor),
        ])
    }
        
    public override func viewDidLayoutSubviews() {
        
        if view.frame.width > view.frame.height {
            ///Landscape
            switch thisInSky {
            case .Birds:
                skyView.frame.size.width = (330.0/1024) * view.frame.width
                skyView.frame.size.height = (306.0 / 1024) * view.frame.width
                skyView.center.x = (700.0/1024) * view.frame.width
                skyView.center.y = (200.0/1366) * view.frame.width
            case .Rainbow:
                skyView.frame.size.width = (854.0/1024) * view.frame.width
                skyView.frame.size.height = (377.0 / 1024) * view.frame.width
                skyView.center.x = (500.0/1024) * view.frame.width
                skyView.center.y = (300.0/1366) * view.frame.width
            case .Sun:
                skyView.frame.size.width = (348.0/1024) * view.frame.width
                skyView.frame.size.height = (362.0 / 1024) * view.frame.width
                skyView.center.x = (500.0/1024) * view.frame.width
                skyView.center.y = (300.0/1366) * view.frame.width
            case .none:
                skyView.frame.size.width = (330.0/1024) * view.frame.width
                skyView.frame.size.height = (306.0 / 1024) * view.frame.width
                skyView.center.x = (700.0/1024) * view.frame.width
                skyView.center.y = (200.0/1366) * view.frame.width
            }
        } else {
            ///Portrait
            switch thisInSky {
            case .Birds:
                skyView.frame.size.width = (330.0/1366) * (view.frame.height)
                skyView.frame.size.height = (306.0/1366) * view.frame.height
                skyView.center.x = (700.0/1024) * view.frame.width
                skyView.center.y = (200.0/1366) * view.frame.height
            case .Rainbow:
                skyView.frame.size.width = (854.0/1366) * (view.frame.height)
                skyView.frame.size.height = (377.0/1366) * view.frame.height
                skyView.center.x = (500.0/1024) * view.frame.width
                skyView.center.y = (300.0/1366) * view.frame.height
            case .Sun:
                skyView.frame.size.width = (348.0/1366) * (view.frame.height)
                skyView.frame.size.height = (362.0/1366) * view.frame.height
                skyView.center.x = (500.0/1024) * view.frame.width
                skyView.center.y = (300.0/1366) * view.frame.height
            case .none:
                skyView.frame.size.width = (330.0/1366) * (view.frame.height)
                skyView.frame.size.height = (306.0/1366) * view.frame.height
                skyView.center.x = (700.0/1024) * view.frame.width
                skyView.center.y = (200.0/1366) * view.frame.height
            }

        }
        
        super.viewDidLayoutSubviews()
    }
    
    func playSound() {
        guard let url = Bundle.main.url(forResource: soundName, withExtension: "mp3") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)

            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)

            guard let player = player else { return }

            player.play()

        } catch let error {
            print(error.localizedDescription)
        }
    }
    
}


