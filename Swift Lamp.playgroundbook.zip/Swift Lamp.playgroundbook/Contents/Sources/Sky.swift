//
//  Sky.swift
//  
//
//  Created by Nathalia Inacio on 15/04/21.
//

import Foundation

public enum Sky: String {
    case Birds = "Birds"
    case Sun = "Sun"
    case Rainbow = "Rainbow"
}
