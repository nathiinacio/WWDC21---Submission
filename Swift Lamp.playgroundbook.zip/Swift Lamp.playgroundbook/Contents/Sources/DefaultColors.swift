//
//  DefaultColors.swift
//
//  Created by Nathalia Mariz de Almeida Salgado Inacio on 18/04/21.
//

import UIKit

let red: UIColor = UIColor(red: 255/255, green: 58/255, blue: 32/255, alpha: 1)
let yellow: UIColor = UIColor(red: 255/255, green: 230/255, blue: 109/255, alpha: 1)
let orange: UIColor = UIColor(red: 241/255, green: 115/255, blue: 0/255, alpha: 1)
let green: UIColor = UIColor(red: 82/255, green: 183/255, blue: 136/255, alpha: 1)
let darkBlue: UIColor = UIColor(red: 29/255, green: 53/255, blue: 87/255, alpha: 1)
let lightBlue: UIColor = UIColor(red: 95/255, green: 168/255, blue: 211/255, alpha: 1)
let purple: UIColor = UIColor(red: 114/255, green: 9/255, blue: 183/255, alpha: 1)
let pink: UIColor = UIColor(red: 244/255, green: 144/255, blue: 151/255, alpha: 1)
let black: UIColor = UIColor.black

let colorsArray: [UIColor] = [red, yellow, orange, green, darkBlue, lightBlue, purple, pink, black]
