//
//  GoodbyeViewController.swift
//  
//
//  Created by Nathalia Mariz de Almeida Salgado Inacio on 18/04/21.
//

import Foundation
import UIKit
import PlaygroundSupport

public class GoodbyeViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    private var currentStep: Int = 0
    
    private var genieMood: [String] = ["SuperHappy", "Thinking", "FullPower"]
    private var genieLines: [String] = ["How could you not tell me\n that you could draw so well?\n That draw back there looked\n like a masterpiece!", "Well, my friend, I guess\n our journey has come to an\n end. I really enjoyed our\n time together! Hope that\n you could relax a\n little bit...", "Now, we have no time to waste! Come on!\n Make some wishes!"]
    
    private var backgroundView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "DesertView")
        view.contentMode = .scaleAspectFill
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var genieView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "SuperHappy")
        view.contentMode = .scaleAspectFit
        view.alpha = 0.0
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var speechBaloonView: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.image = UIImage(named: "SpeechBallon")
        view.contentMode = .scaleAspectFill
        view.isHidden = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var genieLinesView: UILabel = {
        let label = UILabel(frame: .zero)
        label.font = UIFont.systemFont(ofSize: 15)
        label.textColor = .black
        label.textAlignment = .center
        label.numberOfLines = 10
        label.text = "How could you not tell\n me that you could draw\n so well? That draw back\n there looked like\n a masterpiece!"
        label.isHidden = true
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    
    private var continueButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.setImage(UIImage(named: "ContinueButton"), for: .normal)
        button.isHidden = true
        button.contentMode = .scaleAspectFill
        button.isUserInteractionEnabled = false
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    
    private func animateGenie() {
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.genieView.fadeIn()
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
            self.speechBaloonView.isHidden = false
            self.genieLinesView.isHidden = false
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(3), execute: {
            self.continueButton.isHidden = false
            self.continueButton.isUserInteractionEnabled = true
            self.pulsateButton()
        })
    }
    
    private func pulsateButton() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.3
        pulse.fromValue = 0.98
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 1000
        pulse.initialVelocity = 0.3
        pulse.damping = 1.0
        continueButton.layer.add(pulse, forKey: "pulseAnimation")
    }

    
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(self.backgroundView)
        self.view.addSubview(self.speechBaloonView)
        self.view.addSubview(self.genieLinesView)
        self.view.addSubview(self.continueButton)
        self.view.addSubview(self.genieView)
        self.setUpContraints()
        self.animateGenie()
        self.continueButton.addTarget(self, action:  #selector(self.updateView), for: .touchUpInside)
    }
    
    @objc private func updateView() {
        currentStep += 1
        genieView.image = UIImage(named: genieMood[currentStep])
        genieLinesView.text = genieLines[currentStep]
        if currentStep == 2 {
            continueButton.isHidden = true
            continueButton.isUserInteractionEnabled = false
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(3), execute: {
                PlaygroundPage.current.assessmentStatus = .pass(message: "Thank you! **Hope your wishes come true!**")
            })
        }
    }
    
    private func setUpContraints() {
        NSLayoutConstraint.activate([
            backgroundView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            backgroundView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            backgroundView.widthAnchor.constraint(equalTo: view.widthAnchor),
            backgroundView.heightAnchor.constraint(equalTo: view.heightAnchor),
        ])
    }
    
    public override func viewDidLayoutSubviews() {
        
        if view.frame.width > view.frame.height {
            ///Landscape
            genieView.frame.size.width = (426.0/1024) * view.frame.width
            genieView.frame.size.height = (499.0 / 1024) * view.frame.width
            genieView.center.x = (700.0/1024) * view.frame.width
            genieView.center.y = (700.0/1366) * view.frame.width
            
            speechBaloonView.frame.size.width = (354.0/1024) * view.frame.width
            speechBaloonView.frame.size.height = (336.0 / 1024) * view.frame.width
            speechBaloonView.center.x = (400.0/1024) * view.frame.width
            speechBaloonView.center.y = (400.0/1366) * view.frame.width
            
            genieLinesView.frame.size.width = (354.0/1024) * view.frame.width
            genieLinesView.frame.size.height = (300.0 / 1024) * view.frame.width
            genieLinesView.center.x = (400.0/1024) * view.frame.width
            genieLinesView.center.y = (400.0/1366) * view.frame.width
            
            continueButton.frame.size.width = (414.0/1024) * view.frame.width
            continueButton.frame.size.height = (87.0 / 1024) * view.frame.width
            continueButton.center.x = (500.0/1024) * view.frame.width
            continueButton.center.y = (1100.0/1366) * view.frame.width
            
        } else {
            ///Portrait
            genieView.frame.size.width = (426.0/1366) * (view.frame.height)
            genieView.frame.size.height = (499.0/1366) * view.frame.height
            genieView.center.x = (700.0/1024) * view.frame.width
            genieView.center.y = (700.0/1366) * view.frame.height
        
            speechBaloonView.frame.size.width = (354.0/1366) * (view.frame.height)
            speechBaloonView.frame.size.height = (336.0/1366) * view.frame.height
            speechBaloonView.center.x = (400.0/1024) * view.frame.width
            speechBaloonView.center.y = (400.0/1366) * view.frame.height
        
            genieLinesView.frame.size.width = (354.0/1366) * (view.frame.height)
            genieLinesView.frame.size.height = (300.0/1366) * view.frame.height
            genieLinesView.center.x = (400.0/1024) * view.frame.width
            genieLinesView.center.y = (400.0/1366) * view.frame.height
            
            continueButton.frame.size.width = (414.0/1366) * (view.frame.height)
            continueButton.frame.size.height = (87.0/1366) * view.frame.height
            continueButton.center.x = (500.0/1024) * view.frame.width
            continueButton.center.y = (1100.0/1366) * view.frame.height
        }
        
        super.viewDidLayoutSubviews()
    }
    
    
    
    
}
