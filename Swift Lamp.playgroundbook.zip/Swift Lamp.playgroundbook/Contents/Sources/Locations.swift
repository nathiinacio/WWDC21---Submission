//
//  Locations.swift
//
//
//  Created by Nathalia Inacio on 15/04/21.
//

import Foundation

public enum Locations: String {
    case Lake = "Lake"
    case MountainView = "MountainView"
    case Hills = "Hills"
}
