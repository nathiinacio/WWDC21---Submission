/*:
 # Let your **inner artist** out!
 
 I think we are getting there! One more exercise and we are good to go!
 
 **Are you already thinking of your wishes?**
 
 So, I've been walking around the lamp while you were helping Genie with his happy place and guess what? Genie do a lot of drawings! They are **everywhere** in the house!
 
 ## Did you know that drawing is also a relaxing exercise?
 
 That's right! It is call **mindful drawing** and it can help you improve your focus, reduce your anxiety and also improve your drawing skills.
 
 Summing up, it is a visual technique for **putting the mind in a calm place**. Besides, it helps to train **attention and awareness** and also to exercise your creativity.

 ## Let's do it! Tap 'Run My Code' to go to your canvas, my fellow **artist**.
  
 ### Notice
 
Don't feel shy! You can start with anything you want: making drafts, just doodling, drawing how you feel or even the object closest to you. **Don't let your inner critic scares you!**
 
 **Remember that, the important thing is to pay attention to what you are doing! After all, it's the process that matters.**
 
 */

//#-hidden-code
import UIKit
import PlaygroundSupport


let viewController = DrawingViewController()
PlaygroundPage.current.liveView = viewController
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code



