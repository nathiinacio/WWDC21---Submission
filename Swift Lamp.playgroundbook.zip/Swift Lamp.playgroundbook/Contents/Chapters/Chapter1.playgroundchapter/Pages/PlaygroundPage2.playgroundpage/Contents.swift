/*:
 # Inhale the future, exhale the past.
 
 **No way! You might have to pinch me because I can't believe in what just happened!**
 
 Okay, so the good news are that we found a **true magical lamp**, you have your **3 wishes** and besides that, we are **inside the lamp** and **talking to a Genie**!!! I bet this is totally awakening your inner explorer.
 
 So, now we have to **help the Genie to chill a bit**. It's the only way we get your wishes. And honestly, after all this pandemic, **I think we owe to ourselves a calming moment as well.**
 
Luck for us, I have plenty experience in relaxing from my quarentine days.
 
 ## A breathing exercise is perfect to start with!
 
 You see, the way we breathe **affects our whole body**. Breathing exercises are a good way to relax, shake away the tension and even focus in ourselves. Besides that, they are also easy to do! **You just have to be still and pay attencion to your breath.**
 
 ## Are you ready to exhale all your stress? Tap 'Run My Code' and let's help Genie with this first exercise!
 
 ### Notice
 
 The time for this exercise is up to you! You can do it for 30 seconds or for as long as you think necessary to calm down!
 
 */

//#-hidden-code
import UIKit
import PlaygroundSupport


let viewController = BreathingViewController()
PlaygroundPage.current.liveView = viewController
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
