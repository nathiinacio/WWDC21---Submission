/*:
 # Welcome to Swift Lamp!
  
 Hello, fellow adventurer! You might be looking at this desert and wondering where you are. But the question is not **where**, but **when**!
 
 I bet you miss going out, seing your beloved ones, traveling, exploring and getting fresh air. **Well, fear not!** Here you are in the year of 2023, and all this pandemic situation was left behind us.
 
 As the fearless traveler you are, you accepted my invitation to join me in a journey around the world to search for magical artifacts. As you can see, we are in a beautiful desert. **Can you imagine what we are looking for?**
 
 That's right, my friend! **A magical lamp!** The tales say that whoever owns the lamp can make 3 wishes to a **mighty** genie!
 
 **I think we all can say that a few wishes in times like this would come in handy, right?**
 
 
 ## So, check it out! There's is something sparkling in the sand! Tap 'Run My Code' to see what it is!

 
 ### Notice
 
 * For a better experience, I recommend you run this entire playground in a **Side by Side + Landscape** mode.
 
 * If you feel the need of using it in Fullscreen, please do it in Portrait mode.
 
 */


//#-hidden-code
import UIKit
import PlaygroundSupport


let viewController = IntroductionViewController()
PlaygroundPage.current.liveView = viewController
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
