/*:
 # Our mental **vacation spot.**
 
 I have to tell you, my friend. **That made me feel better!** I didn't even know that I was needing to relax. And you?
 
 Well, it still not enough but I think I know just **the thing** that might help our mate, Genie!
 
## We have to take him to his **Happy Place**!!
 
Wait, don't get confuse! I will explain!
 
 Your “Happy Place” is a state of mind, a peacefull place you visualize that calms you down and helps you restore your balance. It is like a mental vacation spot. I used to do it a lot in quarantine, it's like traveling in your own mind but you also #stayhome.
 
 
 ### Let's set up a happy place! Choose our scenario and tap 'Run My Code':
 
 ### Notice
 **This exercise has sound! How about turning on the volume for a more complete and relaxing experience?** 🔊
 
 */

//#-hidden-code
import UIKit
import PlaygroundSupport

public var location:Locations = Locations.Lake
public var sky:Sky = Sky.Birds
public var ground:Ground = Ground.House


public func chooseBackgroundLocation(background: Locations) {
    location = background
}

public func chooseWhatIsInTheSky(inTheSky: Sky) {
    sky = inTheSky
}

public func chooseWhatIsInTheGround(inTheGround: Ground) {
    ground = inTheGround
}

//#-end-hidden-code
chooseBackgroundLocation(background: /*#-editable-code*/.Lake /*#-end-editable-code*/)

chooseWhatIsInTheSky(inTheSky: /*#-editable-code*/.Birds /*#-end-editable-code*/)

chooseWhatIsInTheGround(inTheGround: /*#-editable-code*/.House /*#-end-editable-code*/)
//#-hidden-code

let viewController = HappyPlaceViewController()
viewController.thisBackground = location
viewController.thisInSky = sky
viewController.thisInGround = ground
PlaygroundPage.current.liveView = viewController
PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
