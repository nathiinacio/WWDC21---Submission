/*:
 
 # Time to Say Goodbye...
 
 Well, my traveler friend... What a ride, right?
 
 And even though our journey ends here, I hope you continue your own adventures. **Don't forget to stop to relax from time to time**. After all, it's important to **focus in our mental health**. And, if we learned something here it's that with our imagination and a little bit of technology, **we can do anything**!
 
 Now, Tap 'Run My Code' to say goodbye to Genie!
 
 ## And remember: **make good wishes and never stop hoping!**

 ### Want to hear what you wished for in the next time we meet. But until then, **stay safe**!
 
 # Credits:
 * All sounds used in page 3 were downloaded in Youtube free sound library on
 [youtube](https://studio.youtube.com/channel/UCaXuOFP8OVcJfE_PKRsaOzQ/music)
 * Icons on paged 4 based on [freepik](https://www.freepik.com/free-vector/art-icons-set_4407280.htm#query=drawing%20icons&position=0)
 * Lake background on paged 3 based on [freepik](https://www.freepik.com/free-vector/cottage-near-large-lake-forest-area-sunrise-morning-landscape-nature-background-with-water-mountains-rocks-horizontal-summer-camp-concept_13330437.htm#page=1&query=lake&position=11)
 * Hills background on paged 3 based on [freepik](https://www.freepik.com/free-vector/green-fields-with-tall-trees-illustration_3296550.htm#page=1&query=hills&position=18)
 * Mountain background on paged 3 based on [freepik](https://www.freepik.com/free-vector/cartoon-nature-landscape-with-mountain-forest-deciduous-trees-trunks-clearance_10385782.htm#page=2&query=mountain&position=21)
 * Animals assets on paged 3 based on [freepik](https://www.freepik.com/free-vector/big-animals-set_3817839.htm#page=1&query=animals&position=3)
 
 */

 //#-hidden-code
 import UIKit
 import PlaygroundSupport


 let viewController = GoodbyeViewController()
 PlaygroundPage.current.liveView = viewController
 PlaygroundPage.current.needsIndefiniteExecution = true

 //#-end-hidden-code
